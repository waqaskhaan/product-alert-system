import os
import re
import csv
import time
import yaml
import random
import smtplib
from selenium import webdriver
from email.mime.text import MIMEText
from selenium.webdriver.common.by import By
from email.mime.multipart import MIMEMultipart
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

#__________________________________________________________________________
# Load the YAML file
with open('config.yaml', 'r') as yaml_file:
    config_data = yaml.safe_load(yaml_file)

# Email configuration
email_sender = config_data.get('EMAIL_SENDER')
email_receiver = config_data.get('EMAIL_RECIEVER')
email_password = config_data.get('EMAIL_PASSWORD')

#Contact info
firstName = config_data.get('FIRST_NAME')
lastName = config_data.get('LAST_NAME')
email = config_data.get('EMAIL')
phone = config_data.get('PHONE')

#Shipping
businessName = config_data.get('BUSINESS_NAME')
Address = config_data.get('ADDRESS')
Street = config_data.get('STREET')
City = config_data.get('CITY')
Zip_Code = config_data.get('ZIP_CODE')

#Payment
Name_on_Card = config_data.get('NAME_ON_CARD')
Card_Number = config_data.get('CARD_NUMBER')
Security_Code = config_data.get('SECURITY_CODE')
Card_Expiry = config_data.get('CARD_EXPIRY')

#__________________________________________________________________________


#Function to Remove pop_up ads
def top_ups(d):
    try:
        d.find_element(By.XPATH, '''//*[@id="ltkpopup-close-button"]''').click()
    except:
        pass
    time.sleep(1)
    try:
        d.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.modal.fade.in.modal--active > div > div > div > div > div.age-gate__cta > button''').click()
    except:
        pass
    time.sleep(1)
    try:
        d.find_element(By.CSS_SELECTOR, '''#root > header > section > div.page-alert.cart__reversed > div > div.cart__reversed-close > button''').click()
    except:
        pass

# Function to send an email alert
def send_email(product_name, price_amount, product_link):
    subject = "New Product Alert!"
    body = f"New product added:\n\nName: {product_name}\nPrice: {price_amount}\n\nLink: {product_link}"

    msg = MIMEMultipart()
    msg.attach(MIMEText(body, 'plain'))
    msg['Subject'] = subject
    msg['From'] = email_sender
    msg['To'] = email_receiver

    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(email_sender, email_password)
        server.sendmail(email_sender, email_receiver, msg.as_string())

# Function to read products from CSV file
def read_products_from_csv(file_path):
    products = set()

    try:
        with open(file_path, 'r', newline='', encoding='utf-8') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:
                products.add((row[0], row[1], row[2]))  # Assuming product name, price, and link are in the first, second, and third columns
    except FileNotFoundError:
        pass  # File doesn't exist yet

    return products

# Function to write new products to CSV file
def write_products_to_csv(file_path, new_products):
    with open(file_path, 'a', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        for product in new_products:
            writer.writerow([product[0], product[1], product[2]])

#Function to fill contact info while add to card
def Contact_INFO(driver_2,wait):
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-firstName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').send_keys(firstName)
    except:
        top_ups(driver_2)
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#updateProductListTooltip')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-firstName''').send_keys(firstName)
    
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-lastName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-lastName''').send_keys(lastName) 
    except:
        pass

    # email
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-email')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-email''').send_keys(email)
    except:
        pass
    
    #Phone
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#contact_info_profile-phoneNumber')))
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-phoneNumber''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-phoneNumber''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#contact_info_profile-phoneNumber''').send_keys(phone)
    except:
        pass

    #use as contact info
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.contactInfo__wrapper > div.contactInfo__content > form > div > button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.contactInfo__wrapper > div.contactInfo__content > form > div > button''').click()
    except:
        pass

def Shipping(driver_2, wait):
    # My address checkpoint
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#shipToMyAddress')))
        driver_2.find_element(By.CSS_SELECTOR, '''#shipToMyAddress''').click()
    except:
        pass

    #First name
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-firstName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-firstName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-firstName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-firstName''').send_keys(firstName)
    except:
        pass

    #Last Name
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-lastName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-lastName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-lastName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-lastName''').send_keys(lastName)
    except:
        pass
    
    #Business name (Optinal)
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-companyName')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-companyName''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-companyName''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-companyName''').send_keys(businessName)
    except:
        pass

    #Address
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-streetAddress')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-streetAddress''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-streetAddress''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-streetAddress''').send_keys(Address)
    except:
        pass

    #Street/Floor/Room
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-suiteRoomFloor')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-suiteRoomFloor''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-suiteRoomFloor''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-suiteRoomFloor''').send_keys(Street)
    except:
        pass

    #City
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-labelCity')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelCity''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelCity''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelCity''').send_keys(City)
    except:
        pass

    #Zip-Code
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#standardOrderAddressForm-labelZipCode')))
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelZipCode''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelZipCode''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#standardOrderAddressForm-labelZipCode''').send_keys(Zip_Code)
    except:
        pass

    #Continue to Payment
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.shipping__content > form > button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.shipping__content > form > button''').click()
    except:
        pass

    #Use Unverified Address
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.modal.fade.in.modal--active > div > div > div > div.shipping-modal__addresses > div.shipping-modal__entered-address.shipping-modal__zero-suggestions > button.button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#maincontent > section > div.checkoutContainer > section > section.Region.col-9 > div.shipping__wrapper > div.modal.fade.in.modal--active > div > div > div > div.shipping-modal__addresses > div.shipping-modal__entered-address.shipping-modal__zero-suggestions > button.button''').click()
    except:
        pass

def Payment(driver_2, wait):
    # Name (as it appears on your card)
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#input_general''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#input_general''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#input_general''').clear()
        driver_2.find_element(By.CSS_SELECTOR, '''#input_general''').send_keys(Name_on_Card)
    except:
        pass
    
    # Switch to IFRAME
    driver.switch_to.frame("tokenFrame")

    # Card_Number
    try:
        wait.until(EC.presence_of_element_located((By.ID, 'ccnumfield')))
        driver.find_element(By.ID, "ccnumfield").click()
        driver.find_element(By.ID, "ccnumfield").clear()
        driver.find_element(By.ID, "ccnumfield").send_keys(Card_Number)
    except:
        pass

    # Security Code
    try:
        wait.until(EC.presence_of_element_located((By.ID, 'cccvvfield')))
        driver.find_element(By.ID, "cccvvfield").click()
        driver.find_element(By.ID, "cccvvfield").clear()
        driver.find_element(By.ID, "cccvvfield").send_keys(Security_Code)
    except:
        pass

    # Switch to default
    driver.switch_to.default_content()

    # Expiry
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#expDate''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#expDate''').click()
        driver_2.find_element(By.CSS_SELECTOR, '''#expDate''').send_keys(Card_Expiry)
    except:
        pass

    #Same_as_billing Address
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#billing-from-sg95448244''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#billing-from-sg95448244''').click()
    except:
        pass

    #Place_an_Order
    try:
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#place-order-button''')))
        driver_2.find_element(By.CSS_SELECTOR, '''#place-order-button''').click()
        print("Order is Placed Successfully!!!!!!!!!")
    except:
        pass

# Function to buy product (ADD TO CARD)
def To_Card(product_url, quantity_to_add, product_name, price_amount):
    chrome_options = Options()
    # chrome_options.add_argument("--headless")  # Run Chrome in headless mode
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")  # Disable automation detection
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)

    # Initialize Chrome driver with undetectable options
    driver_2 = webdriver.Chrome(options=chrome_options)

    # Example wait before finding an element
    wait = WebDriverWait(driver_2, 10)

    try:
        driver_2.get(product_url)
        time.sleep(7)
        top_ups(driver_2)
        time.sleep(7)
        top_ups(driver_2)

        try:
            # Check availability 
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > button")))
            driver_2.find_element(By.CSS_SELECTOR, "#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > button").click()
        except:
            top_ups(driver_2)
            driver_2.find_element(By.CSS_SELECTOR, "#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > button").click()

        try:
            # To Me, my store
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.fulfillment-method > div.modal.fade.in.modal--active > div > div > div > div > div.popover__button > button:nth-child(2)')))
            driver_2.find_element(By.CSS_SELECTOR, '#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.fulfillment-method > div.modal.fade.in.modal--active > div > div > div > div > div.popover__button > button:nth-child(2)').click()
        except:
            top_ups(driver_2)
            time.sleep(3)
            driver_2.find_element(By.CSS_SELECTOR, '#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.fulfillment-method > div.modal.fade.in.modal--active > div > div > div > div > div.popover__button > button:nth-child(2)').click()

        def available_quantity_regex(text):
            digits_only = re.search(r'\b(\d+)\b', text)

            if digits_only:
                extracted_digits = digits_only.group(1)
                return int(extracted_digits)
        try:
            # Check available quantity
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > div.card__availability > div > div.availability-info')))
            quantity = driver_2.find_element(By.CSS_SELECTOR, '#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > div.card__availability > div > div.availability-info')
            available_quantity = available_quantity_regex(quantity.text)
        except:
            top_ups(driver_2)
            time.sleep(3)
            # Check available quantity
            quantity = driver_2.find_element(By.CSS_SELECTOR, '#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > div.card__availability > div > div.availability-info')
            available_quantity = available_quantity_regex(quantity.text)

        # Input quantity
        if quantity_to_add <= available_quantity:
            for i in range(quantity_to_add - 1):
                driver_2.find_element(By.CSS_SELECTOR, '#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > div.PDPAvailabilityOnline > div.form-group > div > button.button.square.button-secondary.square-up > span').click()
                time.sleep(0.5)
        else:
            for i in range(available_quantity - 1):
                driver_2.find_element(By.CSS_SELECTOR, '#maincontent > section:nth-child(2) > div > div > div.pdp__info > div.pdp__info-quantity-availability > div > div.PDPAvailabilityOnline > div.form-group > div > button.button.square.button-secondary.square-up > span').click()
                time.sleep(0.5)
        
        try:
            # Click on add to cart button
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#add-to-cart-wrapper > button')))
            driver_2.find_element(By.CSS_SELECTOR, '#add-to-cart-wrapper > button').click()
        except:
            top_ups(driver_2)
            time.sleep(3)
            # Click on add to cart button
            driver_2.find_element(By.CSS_SELECTOR, '#add-to-cart-wrapper > button').click()
        try:
            # Click on product list button
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#updateProductListTooltip')))
            driver_2.find_element(By.CSS_SELECTOR, '#updateProductListTooltip').click()
        except:
            top_ups(driver_2)
            time.sleep(3)
            # Click on product list button
            driver_2.find_element(By.CSS_SELECTOR, '#updateProductListTooltip').click()
        
        try:
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''')))
            driver_2.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''').click()
        except:
            top_ups(driver_2)
            time.sleep(3)
            driver_2.find_element(By.CSS_SELECTOR, '''#root > header > section > div.header-desktop-wrapper > div.container-alignment > section:nth-child(1) > div > section > section > div.miniCart-container > div.tooltipWrapper.clicked.active > div > div.tooltip-content.cartContent > section > section > section > div > button.button.cart-link''').click()

        Contact_INFO(driver_2,wait)
        time.sleep(1)
        Shipping(driver_2,wait)
        time.sleep(1)
        Payment(driver_2, wait)

        # Create or append to the CSV file
        csv_columns = ["Link", "Name", "Quantity", "Price"]
        csv_file = "Data\\add_to_card_product_list.csv"
        # Check if the file exists
        file_exists = os.path.isfile(csv_file)

        with open(csv_file, 'a', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
            
            # Write header only if the file is newly created
            if not file_exists:
                writer.writeheader()

            # Write product information to the CSV file
            writer.writerow({"Link": product_url, "Name": product_name, "Quantity": quantity_to_add, "Price": price_amount})


    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Close the Chrome browser
        driver_2.quit()




#_________________ START _____________________
# List of URLs
urls = [
    "https://www.finewineandgoodspirits.com/whiskey%20release/whiskey-release"
]

# CSV file configuration
csv_file_path = "Data/Products.csv"

# Set up the webdriver (assuming Chrome)
# Set up undetectable Chrome options
chrome_options = Options()
# chrome_options.add_argument("--headless")  # Run Chrome in headless mode
chrome_options.add_argument("--disable-blink-features=AutomationControlled")  # Disable automation detection
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option('useAutomationExtension', False)

# Initialize Chrome driver with undetectable options
driver = webdriver.Chrome(options=chrome_options)

# Example wait before finding an element
wait = WebDriverWait(driver, 10)

try:
    # Read existing products from CSV file
    product_set = read_products_from_csv(csv_file_path)

    # Open the URL in a new tab
    # driver.execute_script("window.open('', '_blank');")
    # driver.switch_to.window(driver.window_handles[-1])
    driver.get(urls[0])

    # Handle the tabs in parallel
    while True:
        # Refresh the current tab
        wait_time = random.randint(15, 30)
        time.sleep(wait_time)
        driver.refresh()

        time.sleep(11)
        # Removing top-ups
        top_ups(driver)
        time.sleep(3)

        # Check for new products and send email alerts
        pagination_cards = driver.find_element(By.CLASS_NAME, 'paginationCards')
        product_cards = pagination_cards.find_element(By.CLASS_NAME, 'products.vertical').find_elements(By.CLASS_NAME, 'product-card-link')

        new_products = set()

        for product_card in product_cards:
            product_name = product_card.get_attribute('aria-label')
            product_link = product_card.get_attribute('href')

            # Extracting price information
            price_container = product_card.find_element(By.CLASS_NAME, 'card__price-container')
            price_amount = price_container.find_element(By.CLASS_NAME, 'card__price-amount').text

            # Check if the product is new
            if (product_name, price_amount, product_link) not in product_set:
                product_set.add((product_name, price_amount, product_link))
                new_products.add((product_name, price_amount, product_link))

                # Send email alert
                send_email(product_name, price_amount, product_link)
                flag = input("Wanna Add to Card? (Y for Yes, N for No): ")
                

                try:
                    flag = str(flag)
                    if flag == "Y" | flag == "y":
                        Quantity_to_card = int(input("Enter Quantity of product to add to card: "))
                        To_Card(product_link, Quantity_to_card, product_name, price_amount)
                    else:
                        pass
                except: 
                    pass

        # Write new products to CSV file
        if new_products:
            write_products_to_csv(csv_file_path, new_products)

except Exception as e:
    print(f"An error occurred: {str(e)}")

finally:
    # Close the browser window
    driver.quit()
